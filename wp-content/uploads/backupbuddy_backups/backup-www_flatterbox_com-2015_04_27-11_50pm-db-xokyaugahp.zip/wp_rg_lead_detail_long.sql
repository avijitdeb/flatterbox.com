CREATE TABLE `wp_rg_lead_detail_long` (  `lead_detail_id` bigint(20) unsigned NOT NULL,  `value` longtext,  PRIMARY KEY (`lead_detail_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_rg_lead_detail_long` DISABLE KEYS */;
INSERT INTO `wp_rg_lead_detail_long` VALUES('4479', 'Advice, sentiments or funny, memorable stories about Hillary. For Hillary\'s friends; only Hillary will see these cards so feel free to include messages that are private and personal. She would love humorous messages.');
INSERT INTO `wp_rg_lead_detail_long` VALUES('4492', 'Advice, sentiments or funny, memorable stories about Hillary. For Hillary\'s friends; only Hillary will see these cards so feel free to include messages that are private and personal. She would love humorous messages.');
/*!40000 ALTER TABLE `wp_rg_lead_detail_long` ENABLE KEYS */;

CREATE TABLE `wp_revslider_settings` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `general` text NOT NULL,  `params` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_revslider_settings` DISABLE KEYS */;
INSERT INTO `wp_revslider_settings` VALUES('1', 'a:0:{}', '');
/*!40000 ALTER TABLE `wp_revslider_settings` ENABLE KEYS */;

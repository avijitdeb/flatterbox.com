CREATE TABLE `wp_revslider_static_slides` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `slider_id` int(9) NOT NULL,  `params` text NOT NULL,  `layers` text NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_revslider_static_slides` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_revslider_static_slides` ENABLE KEYS */;
